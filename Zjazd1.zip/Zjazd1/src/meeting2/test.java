package meeting2;

public class test {
}
