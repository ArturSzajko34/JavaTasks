package meeting2.ForAndWhile;

/*
Zaimplementuj program drukujący liczby z przedziałuod 5 do 15 używając pętlifor.
 */
public class Task1 {
    public static void main(String[] args) {
        int i;
        for (i = 5; i <= 15; i++) {
            System.out.println(i);

        }

    }
}
