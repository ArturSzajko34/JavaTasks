package meeting1.string;

public class Task5 {
    public static void main(String[] args) {
        int a = 106;
        int b = 30;
        int c = 64;
        System.out.print(a + b + c);
    }
}
