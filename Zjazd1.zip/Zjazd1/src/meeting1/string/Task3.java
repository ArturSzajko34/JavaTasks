package meeting1.string;

public class Task3 {
    public static void main(String[] args) {
        float value = 122.333f;
        String converseFloat = String.valueOf(value).replace(".","");
        System.out.println(converseFloat);
    }
}
