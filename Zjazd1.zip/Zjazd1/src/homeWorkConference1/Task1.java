package homeWorkConference1;
/*
Napisz program, który wyświeli 5 razy wyświetli na konsoli napis "This course is nice!".
Niech każdy napis znaduje się w nowej linii.
 */
public class Task1 {
    public static void main(String[] args) {
        System.out.println("This course is nice!");
        System.out.println("This course is nice!");
        System.out.println("This course is nice!");
        System.out.println("This course is nice!");
        System.out.println("This course is nice!");
    }
}
