package homeWorkConference1;

public class Task4 {
    public static void main(String[] args) {
        print("I want to learn Java!");
        print("Being a software engineer is nice!");
    }

    public static void print(String value) {
        int i = 0;
        while (i < 5) {
            i++;
            System.out.println(value);
        }
    }
}
