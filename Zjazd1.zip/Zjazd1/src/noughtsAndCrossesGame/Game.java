package noughtsAndCrossesGame;

public class Game {
    public static void main(String[] args) {

        System.out.println("Welcome to the game");
        Players players1 = new Players(NoughtsAndCrosses.CIRCLET);
        Players players2 = new Players(NoughtsAndCrosses.CROSS);

        System.out.println("Player1: " + players1.getName() + " lest play the symbol: " + NoughtsAndCrosses.CIRCLET.getSymbol());
        System.out.println("Player2: " + players2.getName() + " lest play the symbol: " + NoughtsAndCrosses.CROSS.getSymbol());

        Board.displayBoard();

    }
}
