package homeWorkConference2.Task2;

public class Beer {

    public static int beerPrice = 0;

    public static void addPrice(int beerPrice) {
        Beer.beerPrice += beerPrice;
    }
}

