package meeting1.conditionalStatementElseIf;

import java.util.Scanner;

public class Task7 {
    public static void main(String[] args) {

    }

    public static int enteredNumberOne() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your first number:");
        return scanner.nextInt();
    }

    public static int enteredNumberTwo() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your second number:");
        return scanner.nextInt();
    }

    public static int enteredNumberTree() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your third number:");
        return scanner.nextInt();
    }
}
