package meeting1.string;

public class Task2 {
    public static void main(String[] args) {
        String value = "test";
        System.out.println(value.length());
        System.out.println(value.toUpperCase());
    }
}
