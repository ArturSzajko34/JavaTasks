package meeting1.string;

public class Task1 {
    public static void main(String[] args) {
        String name = "Artur";
        int age = 33;
        int height = 170;
        String country = "Polska";
        int numberOfSiblings = 0;

        int a = 106;
        int b = 30;
        int c = 64;

        System.out.println(a + b + c);
        System.out.println("My name is " + name + ".I'm " + age + " age" + ".I'm height " + height + " tall and live in " + country + ".I have " + numberOfSiblings + " number Of Siblings.");
        System.out.println(name.toUpperCase());
        System.out.println(name.length());

    }
}
