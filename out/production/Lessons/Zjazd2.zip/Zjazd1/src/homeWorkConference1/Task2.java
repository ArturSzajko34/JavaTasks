package homeWorkConference1;

public class Task2 {
    public static void main(String[] args) {
        int x = 5;
        int y = 7;

        y = x * y;
        // y = x + y;
        x = y - x;
        y = y - x;

        System.out.println(x);
        System.out.println(y);
    }
}

