package homeWorkConference1;

public class Task6 {
    /*
    Stwórz metodę printPassedString(String s), która wydrukuje na konsoli przekazany w parametrze String.
     */
    public static void main(String[] args) {
        printPassedString("Test");
    }

    public static void printPassedString(String value) {
        System.out.println(value);
    }
}
