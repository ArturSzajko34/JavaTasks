package homeWorkConference1;
/*
Uzupełnij kod, by programwyświetlałobecny rokdo kwadratu (20212)
 */
public class Task3 {
    public static void main(String[] args) {

        System.out.println(square(2021));
    }

    public static int square(int a) {
        return a * a;
    }

}
