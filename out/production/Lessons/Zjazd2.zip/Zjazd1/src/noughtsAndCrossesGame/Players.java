package noughtsAndCrossesGame;

import java.util.Scanner;

public class Players {

    private final String name;
    private final NoughtsAndCrosses symbol;

    public Players(NoughtsAndCrosses symbol) {
        this.symbol = symbol;
        this.name = enterPlayers();
    }

    public String enterPlayers() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter name players: ");
        return scanner.nextLine();
    }

    public String getName() {
        return name;
    }
}
